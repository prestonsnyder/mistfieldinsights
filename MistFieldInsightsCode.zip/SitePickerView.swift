import SwiftUI

struct SitePickerView: View {
    @Environment(AppState.self) private var app

    var body: some View {
        @Bindable var app = app
        VStack(spacing: 0) {
            VStack(alignment: .leading, spacing: 12) {
                HStack(alignment: .firstTextBaseline) {
                    Text("Sites").font(Theme.ui(22, .semibold)).tracking(-0.22)
                        .foregroundStyle(Theme.ink)
                    Spacer()
                    Button { app.pickerOpen = false; app.siteQuery = "" } label: {
                        Text("Done").font(Theme.ui(14, .medium)).foregroundStyle(Theme.accent)
                    }
                    .buttonStyle(.plain)
                }
                TextField("Search site name", text: $app.siteQuery)
                    .font(Theme.ui(15))
                    .textInputAutocapitalization(.never)
                    .autocorrectionDisabled()
                    .padding(.horizontal, 14).padding(.vertical, 12)
                    .background(Theme.chipBg,
                                in: RoundedRectangle(cornerRadius: 12, style: .continuous))
                    .overlay(RoundedRectangle(cornerRadius: 12, style: .continuous)
                        .stroke(Color(hex: 0xE4DFD5), lineWidth: 1))
                Text(countLabel.uppercased()).font(Theme.mono(10)).tracking(1)
                    .foregroundStyle(Theme.muted2)
            }
            .padding(.horizontal, 20).padding(.top, 20).padding(.bottom, 14)
            .background(Theme.surface)
            .overlay(alignment: .bottom) { Divider().overlay(Theme.hairline) }

            ScrollView {
                VStack(spacing: 8) {
                    ForEach(matches) { s in
                        Button { app.select(site: s) } label: { row(s) }.buttonStyle(.plain)
                    }
                    if matches.isEmpty {
                        Text("No site matches that name.")
                            .font(Theme.ui(13.5)).foregroundStyle(Theme.muted2)
                            .frame(maxWidth: .infinity, alignment: .leading)
                            .padding(.vertical, 28)
                    }
                }
                .padding(.horizontal, 20).padding(.top, 12).padding(.bottom, 40)
            }
        }
        .background(Theme.bg)
    }

    private var matches: [Site] {
        let q = app.siteQuery.trimmingCharacters(in: .whitespaces).lowercased()
        guard !q.isEmpty else { return app.sites }
        return app.sites.filter { "\($0.name) \($0.region)".lowercased().contains(q) }
    }

    private var countLabel: String {
        let n = matches.count
        return "\(n) \(n == 1 ? "site" : "sites") \(app.siteQuery.isEmpty ? "in org" : "matching")"
    }

    private func row(_ s: Site) -> some View {
        let worst: SLEMetric? = {
            guard app.isLive, s.id == app.currentSiteId else { return nil }
            return app.visibleMetrics.min { $0.score < $1.score }
        }()
        return HStack(spacing: 12) {
            VStack(alignment: .leading, spacing: 5) {
                HStack(spacing: 7) {
                    Text(s.name).font(Theme.ui(14, .medium)).foregroundStyle(Theme.ink).lineLimit(1)
                    if s.id == app.currentSiteId {
                        Text("HERE").font(Theme.mono(9, .semibold)).tracking(0.72)
                            .foregroundStyle(.white)
                            .padding(.horizontal, 6).padding(.vertical, 2)
                            .background(Theme.accent,
                                        in: RoundedRectangle(cornerRadius: 5, style: .continuous))
                    }
                }
                HStack(spacing: 6) {
                    chip("\(s.apCount) AP", on: s.apCount > 0)
                    chip(s.hasWired ? "\(s.switchCount) SW" : "no wired", on: s.hasWired)
                    chip(s.hasWAN ? "\(s.gatewayCount) GW" : "no WAN", on: s.hasWAN)
                }
                Text(s.region).font(Theme.mono(10)).foregroundStyle(Theme.muted2)
            }
            Spacer(minLength: 8)
            VStack(alignment: .trailing, spacing: 2) {
                if let worst {
                    Text("\(Int(worst.score.rounded()))%")
                        .font(Theme.mono(17, .semibold)).tracking(-0.51)
                        .foregroundStyle(Theme.status(worst.score))
                    Text(worst.name.uppercased()).font(Theme.mono(9)).tracking(0.54)
                        .foregroundStyle(Theme.muted2)
                } else {
                    Text("—")
                        .font(Theme.mono(17, .semibold))
                        .foregroundStyle(Theme.muted2)
                    Text("SELECT").font(Theme.mono(9)).tracking(0.54)
                        .foregroundStyle(Theme.muted2)
                }
            }
        }
        .card(radius: 16, padding: 13)
    }

    private func chip(_ text: String, on: Bool) -> some View {
        Text(text)
            .font(Theme.mono(10))
            .foregroundStyle(on ? Theme.ink3 : Theme.muted2)
            .padding(.horizontal, 7).padding(.vertical, 3)
            .background(on ? Theme.chipBg : Theme.surfaceAlt,
                        in: RoundedRectangle(cornerRadius: 6, style: .continuous))
    }
}
