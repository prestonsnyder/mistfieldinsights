import Foundation
import Security

actor MistAPI {
    enum APIError: LocalizedError {
        case notConfigured
        case http(Int)
        case decoding(String)

        var errorDescription: String? {
            switch self {
            case .notConfigured: "Token and site ID are both required."
            case .http(let code): "Mist returned HTTP \(code)."
            case .decoding: "Could not read the response."
            }
        }
    }

    struct SLEResult {
        let score: Double
        let impacted: Int
        let classifiers: [Classifier]
    }

    var host: URL
    private var token: String
    private let session: URLSession

    private static let maxResponseBytes = 2_000_000
    private static let allowedMetrics: Set<String> = [
        "time-to-connect", "successful-connect", "successful-connects", "failed-to-connect",
        "coverage", "roaming", "ap-health", "ap-availability", "throughput", "capacity",
        "switch-health", "health", "switch-successful-connect", "switch-successful-connects",
        "switch-throughput", "wan-link-health", "application-health"
    ]

    init(host: URL = URL(string: "https://api.ac2.mist.com")!, token: String = "") {
        self.host = host
        self.token = token
        let cfg = URLSessionConfiguration.ephemeral
        cfg.timeoutIntervalForRequest = 15
        cfg.timeoutIntervalForResource = 30
        cfg.urlCache = nil
        cfg.httpCookieStorage = nil
        cfg.httpShouldSetCookies = false
        cfg.requestCachePolicy = .reloadIgnoringLocalCacheData
        self.session = URLSession(configuration: cfg)
    }

    func configure(host: URL, token: String) {
        self.host = host
        self.token = token
    }

    private func requireID(_ id: String) throws -> String {
        guard TokenStore.isValidID(id) else { throw APIError.notConfigured }
        return id
    }

    private func requireMetric(_ metric: String) throws -> String {
        guard Self.allowedMetrics.contains(metric) else { throw APIError.notConfigured }
        return metric
    }

    private func request(_ path: String, query: [String: String] = [:]) throws -> URLRequest {
        guard !token.isEmpty, TokenStore.isValidToken(token) else { throw APIError.notConfigured }

        var components = URLComponents(url: host, resolvingAgainstBaseURL: false)!
        components.path = path.hasPrefix("/") ? path : "/" + path
        if !query.isEmpty {
            components.queryItems = query.map { URLQueryItem(name: $0.key, value: $0.value) }
        }
        guard let url = components.url else { throw APIError.http(0) }

        var request = URLRequest(url: url)
        request.cachePolicy = .reloadIgnoringLocalCacheData
        request.setValue("Token \(token)", forHTTPHeaderField: "Authorization")
        request.setValue("application/json", forHTTPHeaderField: "Accept")
        return request
    }

    private func perform(_ request: URLRequest) async throws -> Data {
        let (data, response) = try await session.data(for: request)
        guard let http = response as? HTTPURLResponse else { throw APIError.http(0) }
        guard (200..<300).contains(http.statusCode) else { throw APIError.http(http.statusCode) }
        guard data.count <= Self.maxResponseBytes else { throw APIError.decoding("too large") }
        return data
    }

    private func get<T: Decodable>(
        _ path: String,
        query: [String: String] = [:],
        as: T.Type
    ) async throws -> T {
        let data = try await perform(try request(path, query: query))
        do { return try JSONDecoder().decode(T.self, from: data) }
        catch { throw APIError.decoding("decode") }
    }

    private func getData(_ path: String, query: [String: String] = [:]) async throws -> Data {
        try await perform(try request(path, query: query))
    }

    struct SelfDTO: Decodable {
        struct Privilege: Decodable {
            let scope: String?
            let org_id: String?
            let org_name: String?
            let name: String?
            let site_id: String?
        }
        let email: String?
        let privileges: [Privilege]?
    }

    /// Orgs the token can see, derived from /api/v1/self privileges.
    func orgs() async throws -> [(id: String, name: String)] {
        let me = try await get("/api/v1/self", as: SelfDTO.self)
        var seen = Set<String>()
        var out: [(id: String, name: String)] = []
        for p in me.privileges ?? [] {
            guard let id = p.org_id, !id.isEmpty, !seen.contains(id) else { continue }
            seen.insert(id)
            let label = p.org_name ?? (p.scope == "org" ? p.name : nil) ?? "Org \(id.prefix(8))"
            out.append((id: id, name: label))
        }
        return out.sorted { $0.name.localizedCaseInsensitiveCompare($1.name) == .orderedAscending }
    }

    struct SiteDTO: Decodable { let id: String; let name: String; let country_code: String? }

    func sites(orgId: String) async throws -> [SiteDTO] {
        let org = try requireID(orgId)
        return try await get("/api/v1/orgs/\(org)/sites", as: [SiteDTO].self)
    }

    struct DeviceStatDTO: Decodable {
        let mac: String?
        let name: String?
        let type: String?
        let model: String?
        let status: String?
        let num_clients: Int?
        let uptime: Double?
    }

    func devices(siteId: String) async throws -> [DeviceStatDTO] {
        let site = try requireID(siteId)
        return try await get(
            "/api/v1/sites/\(site)/stats/devices",
            query: ["type": "all", "limit": "200"],
            as: [DeviceStatDTO].self
        )
    }

    struct SLESummaryDTO: Decodable {
        struct Samples: Decodable {
            let degraded: [Double?]?
            let total: [Double?]?
            let value: [Double?]?
        }
        struct Impact: Decodable {
            let num_users: Int?
            let num_aps: Int?
        }
        struct ClassifierDTO: Decodable {
            let name: String?
            let samples: Samples?
            let impact: Impact?
        }
        struct SLEObject: Decodable {
            let samples: Samples?
            let success: Double?
            let value: Double?
        }

        let start: Double?
        let end: Double?
        let success: Double?
        let value: Double?
        let sleNumber: Double?
        let sleObject: SLEObject?
        let impact: Impact?
        let classifiers: [ClassifierDTO]?

        enum CodingKeys: String, CodingKey {
            case start, end, success, value, sle, impact, classifiers
        }

        init(from decoder: Decoder) throws {
            let c = try decoder.container(keyedBy: CodingKeys.self)
            start = try c.decodeIfPresent(Double.self, forKey: .start)
            end = try c.decodeIfPresent(Double.self, forKey: .end)
            success = try c.decodeIfPresent(Double.self, forKey: .success)
            value = try c.decodeIfPresent(Double.self, forKey: .value)
            impact = try c.decodeIfPresent(Impact.self, forKey: .impact)
            classifiers = try c.decodeIfPresent([ClassifierDTO].self, forKey: .classifiers)
            sleNumber = try? c.decodeIfPresent(Double.self, forKey: .sle)
            sleObject = try? c.decodeIfPresent(SLEObject.self, forKey: .sle)
        }

        static func sampleSum(_ samples: Samples?) -> (degraded: Double, total: Double) {
            let d = samples?.degraded?.compactMap { $0 }.reduce(0, +) ?? 0
            let t = samples?.total?.compactMap { $0 }.reduce(0, +) ?? 0
            return (d, t)
        }

        func score() -> Double? {
            let s = Self.sampleSum(sleObject?.samples)
            if s.total > 0 { return (1 - s.degraded / s.total) * 100 }
            let values = sleObject?.samples?.value?.compactMap { $0 } ?? []
            if !values.isEmpty {
                let good = values.filter { $0 <= 2 }.count
                return Double(good) / Double(values.count) * 100
            }
            for raw in [sleNumber, sleObject?.success, sleObject?.value, success, value] {
                if let raw { return raw <= 1 ? raw * 100 : raw }
            }
            return nil
        }

        func mappedClassifiers() -> [Classifier] {
            let raw = classifiers ?? []
            let denom = raw.map { Self.sampleSum($0.samples).degraded }.reduce(0, +)

            return raw.compactMap { c in
                guard let name = c.name, !name.isEmpty else { return nil }
                let s = Self.sampleSum(c.samples)
                let share: Double
                if s.degraded > 0, denom > 0 {
                    share = s.degraded / denom * 100
                } else if s.degraded > 0, s.total > 0 {
                    share = min(100, s.degraded / s.total * 100)
                } else {
                    share = 0
                }
                return Classifier(
                    name: name.replacingOccurrences(of: "-", with: " "),
                    share: share,
                    isFailure: share > 0,
                    subs: []
                )
            }
        }

        func result() -> SLEResult? {
            guard let score = score() else { return nil }
            return SLEResult(
                score: score,
                impacted: impact?.num_users ?? impact?.num_aps ?? 0,
                classifiers: mappedClassifiers()
            )
        }
    }

    func sleSummary(siteId: String, metric: String, duration: String) async throws -> SLEResult? {
        let site = try requireID(siteId)
        let metric = try requireMetric(metric)
        let paths = [
            "/api/v1/sites/\(site)/sle/site/\(site)/metric/\(metric)/summary",
            "/api/v1/sites/\(site)/sle/site/\(site)/metric/\(metric)/summary-trend"
        ]
        for path in paths {
            if let dto = try? await get(path, query: ["duration": duration], as: SLESummaryDTO.self),
               let result = dto.result() {
                return result
            }
        }
        return nil
    }

    struct ActionDTO: Decodable {
        let type: String?
        let group: String?
        let severity: String?
        let site_id: String?
        let hostnames: [String]?
        let aps: [String]?
        let switches: [String]?
        let gateways: [String]?
        let count: Int?
    }
    struct ActionsEnvelope: Decodable { let results: [ActionDTO]? }

    func marvisActions(orgId: String, siteId: String) async throws -> [ActionDTO] {
        _ = try requireID(orgId)
        let site = try requireID(siteId)
        let env = try await get(
            "/api/v1/sites/\(site)/alarms/search",
            query: [
                "group": "marvis",
                "acked": "false",
                "resolved": "false",
                "duration": "1d",
                "limit": "50"
            ],
            as: ActionsEnvelope.self
        )
        return env.results ?? []
    }

    struct MiniDTO: Decodable {
        let type: String?
        let status: String?
        let success: Bool?
        let reason: String?
        let timestamp: Double?

        private enum CodingKeys: String, CodingKey {
            case type, status, success, reason, timestamp, results, passed, result
        }

        private struct Inner: Decodable {
            let status: String?
            let result: String?
            let success: FlexBool?
            let passed: FlexBool?
            let reason: String?
        }

        /// Bool, 0/1, or a status string from the Mist payload.
        private struct FlexBool: Decodable {
            let value: Bool?
            let text: String?
            init(from decoder: Decoder) throws {
                let c = try decoder.singleValueContainer()
                if let b = try? c.decode(Bool.self) {
                    value = b
                    text = b ? "passed" : "failed"
                    return
                }
                if let i = try? c.decode(Int.self) {
                    value = i != 0
                    text = i != 0 ? "passed" : "failed"
                    return
                }
                if let s = try? c.decode(String.self) {
                    text = s
                    let v = s.lowercased()
                    if ["true", "1", "yes", "success", "succeeded", "pass", "passed", "ok"].contains(v) {
                        value = true
                    } else if ["false", "0", "no", "fail", "failed", "error"].contains(v) {
                        value = false
                    } else {
                        value = nil
                    }
                    return
                }
                value = nil
                text = nil
            }
        }

        init(from decoder: Decoder) throws {
            let c = try decoder.container(keyedBy: CodingKeys.self)
            type = try c.decodeIfPresent(String.self, forKey: .type)
            reason = try c.decodeIfPresent(String.self, forKey: .reason)

            if let d = try c.decodeIfPresent(Double.self, forKey: .timestamp) {
                timestamp = d
            } else if let i = try c.decodeIfPresent(Int.self, forKey: .timestamp) {
                timestamp = Double(i)
            } else {
                timestamp = nil
            }

            var status = try c.decodeIfPresent(String.self, forKey: .status)
            if status == nil { status = try c.decodeIfPresent(String.self, forKey: .result) }

            var success: Bool?
            if let flex = try c.decodeIfPresent(FlexBool.self, forKey: .success) {
                success = flex.value
                if status == nil { status = flex.text }
            }
            if success == nil, let flex = try c.decodeIfPresent(FlexBool.self, forKey: .passed) {
                success = flex.value
                if status == nil { status = flex.text }
            }

            // Mist nests the outcome: "results": { "dns": { "status": "passed" } }
            if let keyed = try? c.decode([String: Inner].self, forKey: .results) {
                let inner = Self.inner(for: type, in: keyed) ?? keyed.values.first
                if status == nil { status = inner?.status ?? inner?.result }
                if success == nil { success = inner?.success?.value ?? inner?.passed?.value }
            } else if let inner = try? c.decode(Inner.self, forKey: .results) {
                if status == nil { status = inner.status ?? inner.result }
                if success == nil { success = inner.success?.value ?? inner.passed?.value }
            }

            self.status = status
            self.success = success
        }

        private static func inner(for type: String?, in keyed: [String: Inner]) -> Inner? {
            guard let type else { return nil }
            if let hit = keyed[type] { return hit }
            let lower = type.lowercased()
            return keyed.first { $0.key.lowercased() == lower }?.value
        }
    }

    struct MinisEnvelope: Decodable {
        let results: [MiniDTO]?
    }

    func minis(siteId: String) async throws -> [MiniDTO] {
        let site = try requireID(siteId)
        let data = try await getData(
            "/api/v1/sites/\(site)/synthetic_test/search",
            query: ["duration": "1d", "limit": "100"]
        )
        if let env = try? JSONDecoder().decode(MinisEnvelope.self, from: data) {
            return env.results ?? []
        }
        if let list = try? JSONDecoder().decode([MiniDTO].self, from: data) {
            return list
        }
        throw APIError.decoding("shape")
    }
}

struct SavedConnection: Equatable, Sendable {
    var token: String
    var orgId: String
    var orgName: String
    var siteId: String
}

enum TokenStore: Sendable {
    private static let service = "mist.fieldinsights"
    private static let account = "mist.connection"

    private static var baseQuery: [String: Any] {
        [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: service,
            kSecAttrAccount as String: account
        ]
    }

    nonisolated static func isValidToken(_ token: String) -> Bool {
        let t = token.trimmingCharacters(in: .whitespacesAndNewlines)
        guard (16...512).contains(t.count) else { return false }
        return t.unicodeScalars.allSatisfy { scalar in
            scalar.isASCII && scalar != "\r" && scalar != "\n" && !Character(scalar).isWhitespace
        }
    }

    nonisolated static func isValidID(_ id: String) -> Bool {
        let charset = CharacterSet.alphanumerics.union(CharacterSet(charactersIn: "-_"))
        return (8...64).contains(id.count) && id.unicodeScalars.allSatisfy { charset.contains($0) }
    }

    static var hasItem: Bool {
        var query = baseQuery
        query[kSecReturnData as String] = false
        query[kSecMatchLimit as String] = kSecMatchLimitOne
        return SecItemCopyMatching(query as CFDictionary, nil) == errSecSuccess
    }

    @discardableResult
    static func save(_ connection: SavedConnection) -> Bool {
        guard isValidToken(connection.token) else { return false }
        let payload: [String: String] = [
            "token": connection.token,
            "orgId": connection.orgId,
            "orgName": connection.orgName,
            "siteId": connection.siteId
        ]
        guard let data = try? JSONEncoder().encode(payload) else { return false }

        SecItemDelete(baseQuery as CFDictionary)
        var add = baseQuery
        add[kSecValueData as String] = data
        add[kSecAttrAccessible as String] = kSecAttrAccessibleWhenUnlockedThisDeviceOnly
        add[kSecAttrSynchronizable as String] = kCFBooleanFalse!
        return SecItemAdd(add as CFDictionary, nil) == errSecSuccess
    }

    static func load() -> SavedConnection? {
        var query = baseQuery
        query[kSecReturnData as String] = true
        query[kSecMatchLimit as String] = kSecMatchLimitOne
        var out: AnyObject?
        guard SecItemCopyMatching(query as CFDictionary, &out) == errSecSuccess,
              let data = out as? Data,
              let payload = try? JSONDecoder().decode([String: String].self, from: data),
              let token = payload["token"], isValidToken(token) else { return nil }
        return SavedConnection(
            token: token,
            orgId: payload["orgId"] ?? "",
            orgName: payload["orgName"] ?? "",
            siteId: payload["siteId"] ?? ""
        )
    }

    static func delete() {
        SecItemDelete(baseQuery as CFDictionary)
    }
}
