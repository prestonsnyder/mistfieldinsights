import SwiftUI

struct SLEDetailView: View {
    @Environment(AppState.self) private var app

    var body: some View {
        Group {
            if let m = app.selectedMetric {
                loaded(m)
            } else {
                VStack(spacing: 0) {
                    BackHeader(title: "Service level", subtitle: app.site.name,
                               backLabel: app.site.name)
                    DashedNote(text: "No service-level metric is available for this site yet.")
                        .padding(20)
                    Spacer()
                }
            }
        }
        .background(Theme.bg)
    }

    private func loaded(_ m: SLEMetric) -> some View {
        VStack(spacing: 0) {
            BackHeader(title: m.name, subtitle: "\(app.site.name) · \(rangeLabel)",
                       backLabel: app.site.name)

            ScrollView {
                VStack(alignment: .leading, spacing: 0) {
                    chips
                    headline(m)
                    VStack(alignment: .leading, spacing: 12) {
                        SectionHeader(text: m.score >= 99.5 ? "Classifiers (no failures)" : "Failure classifiers")
                        classifiers(m)
                        SectionHeader(text: "Worst offenders").padding(.top, 10)
                        offenders
                    }
                    .padding(.horizontal, 20)
                }
                .padding(.bottom, 32)
            }
        }
    }

    private var rangeLabel: String {
        app.range == "1H" ? "last hour" : app.range == "24H" ? "last 24 hours" : "last 7 days"
    }

    private var chips: some View {
        ScrollView(.horizontal, showsIndicators: false) {
            HStack(spacing: 6) {
                ForEach(app.visibleMetrics) { metric in
                    let on = metric.key == app.selectedMetricKey
                    Button {
                        app.selectedMetricKey = metric.key
                        app.openClassifier = nil
                    } label: {
                        Text(metric.name)
                            .font(Theme.mono(11, .semibold))
                            .foregroundStyle(on ? .white : Theme.muted)
                            .padding(.horizontal, 13).padding(.vertical, 8)
                            .background(on ? Theme.accent : Theme.surface, in: Capsule())
                            .overlay(Capsule().stroke(on ? Theme.accent : Color(hex: 0xE4DFD5),
                                                      lineWidth: 1))
                    }
                    .buttonStyle(.plain)
                }
            }
            .padding(.horizontal, 20)
        }
        .padding(.top, 14)
    }

    private func headline(_ m: SLEMetric) -> some View {
        HStack(alignment: .bottom, spacing: 16) {
            VStack(alignment: .leading, spacing: 4) {
                Text("\(Int(m.score.rounded()))%")
                    .font(Theme.mono(46, .semibold))
                    .tracking(-1.84)
                    .foregroundStyle(Theme.ink)
                Text("target 95% · \(rangeLabel)")
                    .font(Theme.ui(12.5)).foregroundStyle(Theme.muted)
            }
            HStack(alignment: .bottom, spacing: 3) {
                ForEach(0..<16, id: \.self) { i in
                    let v = min(100, max(12, m.score + sin(Double(i + m.name.count) * 1.3) * 9
                                         - (i > 11 ? 7 : 0)))
                    UnevenRoundedRectangle(topLeadingRadius: 2, topTrailingRadius: 2)
                        .fill(Theme.status(v))
                        .frame(height: 54 * v / 100)
                        .frame(maxWidth: .infinity)
                }
            }
            .frame(height: 54)
        }
        .padding(.horizontal, 20)
        .padding(.top, 18)
        .padding(.bottom, 20)
    }

    @ViewBuilder
    private func classifiers(_ m: SLEMetric) -> some View {
        if m.classifiers.isEmpty {
            DashedNote(text: app.isLive
                       ? "No classifier breakdown for this metric in the selected window."
                       : "Connect a token to load live classifiers.")
        } else {
            ForEach(m.classifiers) { c in
                VStack(alignment: .leading, spacing: 10) {
                    HStack(spacing: 12) {
                        Text(c.name).font(Theme.ui(13.5, .medium)).foregroundStyle(Theme.ink)
                        Spacer()
                        Text("\(Int(c.share.rounded()))%").font(Theme.mono(15, .semibold))
                            .foregroundStyle(c.share > 0 ? Theme.bad : Theme.good)
                    }
                    GeometryReader { geo in
                        ZStack(alignment: .leading) {
                            Capsule().fill(Color(hex: 0xF0ECE4))
                            Capsule()
                                .fill(c.share > 0 ? Theme.bad : Theme.good)
                                .frame(width: geo.size.width * min(1, c.share / 100))
                        }
                    }
                    .frame(height: 6)
                }
                .card(radius: 16, padding: 14)
            }
        }
    }

    private var offenders: some View {
        ForEach(app.devices.sorted { $0.health < $1.health }.prefix(4)) { d in
            Button { app.path.append(Route.device(d.id)) } label: {
                HStack(spacing: 12) {
                    VStack(alignment: .leading, spacing: 2) {
                        Text(d.name).font(Theme.ui(13, .medium)).foregroundStyle(Theme.ink)
                        Text("\(d.model) · \(d.location)")
                            .font(Theme.mono(10)).foregroundStyle(Theme.muted2)
                    }
                    Spacer()
                    Text("\(Int(d.health))%")
                        .font(Theme.mono(14, .semibold))
                        .foregroundStyle(Theme.status(d.health))
                }
                .card(radius: 12, padding: 12)
            }
            .buttonStyle(.plain)
        }
    }
}

struct BackHeader: View {
    let title: String
    let subtitle: String
    let backLabel: String
    @Environment(AppState.self) private var app

    var body: some View {
        VStack(alignment: .leading, spacing: 0) {
            Button { if !app.path.isEmpty { app.path.removeLast() } } label: {
                Text("‹ \(backLabel)")
                    .font(Theme.mono(11.5)).foregroundStyle(Theme.accent)
            }
            .buttonStyle(.plain)
            .padding(.horizontal, 20).padding(.top, 16).padding(.bottom, 9)

            HStack(spacing: 12) {
                VStack(alignment: .leading, spacing: 3) {
                    Text(title).font(Theme.ui(20, .semibold)).tracking(-0.24)
                        .foregroundStyle(Theme.ink).lineLimit(1)
                    Text(subtitle).font(Theme.mono(10.5)).foregroundStyle(Theme.muted2).lineLimit(1)
                }
                Spacer(minLength: 8)
                StatusPill(isLive: app.isLive, isLoading: app.isLoading)
            }
            .padding(.horizontal, 20).padding(.bottom, 13)

            Divider().overlay(Theme.hairline)
        }
        .background(Theme.surface)
    }
}
