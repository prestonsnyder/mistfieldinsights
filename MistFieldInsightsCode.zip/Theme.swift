import SwiftUI

enum Theme {
    static let bg = Color(hex: 0xF7F5F1)
    static let surface = Color.white
    static let surfaceAlt = Color(hex: 0xFBFAF7)
    static let chipBg = Color(hex: 0xF2EFE9)
    static let hairline = Color(hex: 0xEAE5DC)
    static let hairlineDashed = Color(hex: 0xDFD9CE)
    static let ink = Color(hex: 0x1A1917)
    static let ink2 = Color(hex: 0x2A2723)
    static let ink3 = Color(hex: 0x56504A)
    static let muted = Color(hex: 0x7A736A)
    static let muted2 = Color(hex: 0xA39B8F)
    static let tabInactive = Color(hex: 0xB0A99E)

    static let accent = Color(hex: 0x6B4BD6)
    static let good = Color(hex: 0x2E9265)
    static let warn = Color(hex: 0xC8912B)
    static let bad = Color(hex: 0xC4453A)

    /// The single status rule used everywhere a score is coloured.
    static func status(_ score: Double) -> Color {
        score >= 92 ? good : score >= 80 ? warn : bad
    }

    // Swap these two for .system(...) if you do not bundle the fonts.
    static func ui(_ size: CGFloat, _ weight: Font.Weight = .regular) -> Font {
        .custom("Sora", size: size).weight(weight)
    }
    static func mono(_ size: CGFloat, _ weight: Font.Weight = .regular) -> Font {
        .custom("IBMPlexMono", size: size).weight(weight)
    }
}

extension Color {
    init(hex: UInt32) {
        self.init(.sRGB,
                  red: Double((hex >> 16) & 0xFF) / 255,
                  green: Double((hex >> 8) & 0xFF) / 255,
                  blue: Double(hex & 0xFF) / 255,
                  opacity: 1)
    }
}

struct CardStyle: ViewModifier {
    var radius: CGFloat = 16
    var padding: CGFloat = 14
    func body(content: Content) -> some View {
        content
            .padding(padding)
            .background(Theme.surface)
            .clipShape(RoundedRectangle(cornerRadius: radius, style: .continuous))
            .overlay(
                RoundedRectangle(cornerRadius: radius, style: .continuous)
                    .stroke(Theme.hairline, lineWidth: 1)
            )
    }
}

extension View {
    func card(radius: CGFloat = 16, padding: CGFloat = 14) -> some View {
        modifier(CardStyle(radius: radius, padding: padding))
    }
}

struct SectionHeader: View {
    let text: String
    var trailing: AnyView? = nil
    var body: some View {
        HStack(alignment: .firstTextBaseline) {
            Text(text.uppercased())
                .font(Theme.mono(11))
                .tracking(1.5)
                .foregroundStyle(Theme.muted2)
            Spacer()
            if let trailing { trailing }
        }
    }
}
