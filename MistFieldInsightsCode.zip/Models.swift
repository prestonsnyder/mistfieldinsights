import Foundation

struct Site: Identifiable, Hashable {
    let id: String
    let name: String
    let region: String
    var apCount: Int
    var switchCount: Int
    var gatewayCount: Int
    var bias: Double = 0

    var hasWired: Bool { switchCount > 0 }
    var hasWAN: Bool { gatewayCount > 0 }

    static let empty = Site(id: "", name: "No site", region: "",
                            apCount: 0, switchCount: 0, gatewayCount: 0)
}

enum SLEFamily: String, CaseIterable, Hashable {
    case wireless = "Wireless"
    case wired = "Wired"
    case wan = "WAN"
}

enum SLECatalog {
    static let metrics: [SLEMetric] = [
        SLEMetric(key: "time-to-connect", name: "Time to Connect", family: .wireless, score: 0, delta: 0, impacted: 0),
        SLEMetric(key: "successful-connect", name: "Successful Connect", family: .wireless, score: 0, delta: 0, impacted: 0),
        SLEMetric(key: "coverage", name: "Coverage", family: .wireless, score: 0, delta: 0, impacted: 0),
        SLEMetric(key: "roaming", name: "Roaming", family: .wireless, score: 0, delta: 0, impacted: 0),
        SLEMetric(key: "ap-health", name: "AP Health", family: .wireless, score: 0, delta: 0, impacted: 0),
        SLEMetric(key: "capacity", name: "Capacity", family: .wireless, score: 0, delta: 0, impacted: 0),
        SLEMetric(key: "switch-health", name: "Switch Health", family: .wired, score: 0, delta: 0, impacted: 0, scope: "switches"),
        SLEMetric(key: "switch-successful-connect", name: "Successful Connect (wired)", family: .wired, score: 0, delta: 0, impacted: 0, scope: "access ports"),
        SLEMetric(key: "switch-throughput", name: "Wired Throughput", family: .wired, score: 0, delta: 0, impacted: 0, scope: "uplinks"),
        SLEMetric(key: "wan-link-health", name: "WAN Link Health", family: .wan, score: 0, delta: 0, impacted: 0, scope: "gateways"),
        SLEMetric(key: "application-health", name: "Application Health", family: .wan, score: 0, delta: 0, impacted: 0, scope: "SaaS breakout")
    ]
}

struct SLEMetric: Identifiable, Hashable {
    var id: String { key }
    let key: String
    let name: String
    let family: SLEFamily
    var score: Double
    var delta: Double
    var impacted: Int
    var scope: String = ""
    var classifiers: [Classifier] = []
}

struct Classifier: Identifiable, Hashable {
    var id: String { name }
    let name: String
    let share: Double
    var isFailure: Bool = false
    let subs: [SubCause]

    struct SubCause: Identifiable, Hashable {
        var id: String { name }
        let name: String
        let value: String
    }
}

struct MarvisAction: Identifiable, Hashable {
    var id: String { title }
    enum Severity: String { case critical = "Critical", major = "Major", warning = "Warning" }
    let severity: Severity
    let title: String
    let detail: String
    let impacted: Int
    let impactedUnit: String
    let cause: String
    let cta: String
    let requires: DeviceKind?
}

struct Mini: Identifiable, Hashable {
    var id: String { name }
    enum Result: String { case pass = "PASS", warn = "WARN", fail = "FAIL" }
    let name: String
    var result: Result
    var age: String
    let requires: DeviceKind?
}

enum DeviceKind: String, Hashable {
    case ap, switchDevice, gateway
}

struct Device: Identifiable, Hashable {
    let id: String
    let kind: DeviceKind
    let name: String
    let model: String
    let mac: String
    let location: String
    var clients: Int
    var portsUp: Int
    var portsTotal: Int
    var health: Double
    var isDown: Bool
}
