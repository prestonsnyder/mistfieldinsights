import SwiftUI

struct DeviceDetailView: View {
    let deviceId: String
    @Environment(AppState.self) private var app
    @State private var miniRunning = false

    private var device: Device? { app.devices.first { $0.id == deviceId } }

    var body: some View {
        Group {
            if let d = device { content(d) } else { Color.clear }
        }
        .background(Theme.bg)
    }

    private func content(_ d: Device) -> some View {
        VStack(spacing: 0) {
            BackHeader(title: d.name, subtitle: "\(d.model) · \(d.mac)", backLabel: "Devices")

            ScrollView {
                VStack(alignment: .leading, spacing: 0) {
                    summary(d)
                    VStack(alignment: .leading, spacing: 12) {
                        if !rows(d).isEmpty {
                            SectionHeader(text: portsLabel(d))
                            ForEach(rows(d), id: \.key) { r in rowView(r) }
                        }

                        if app.isLive && rows(d).isEmpty {
                            DashedNote(text: "Radio, port, and PoE detail are not in /stats/devices. Name, model, MAC, clients, and status above are live.")
                        } else if d.kind == .ap && !app.hasWired {
                            DashedNote(text: "No managed switch at this site. The AP uplinks to third-party gear, so port and PoE detail are not available.")
                        } else if !uplink(d).isEmpty {
                            SectionHeader(text: d.kind == .ap ? "Uplink switch port" : "Health")
                            VStack(spacing: 11) {
                                ForEach(uplink(d), id: \.0) { label, value, color in
                                    HStack {
                                        Text(label).font(Theme.ui(12.5)).foregroundStyle(Theme.muted)
                                        Spacer()
                                        Text(value).font(Theme.mono(12, .medium)).foregroundStyle(color)
                                    }
                                }
                            }
                            .card()
                        }

                        SectionHeader(text: "Marvis insights").padding(.top, 10)
                        ForEach(insights(d), id: \.0) { title, detail, color in
                            HStack(alignment: .top, spacing: 11) {
                                Circle().fill(color).frame(width: 8, height: 8).padding(.top, 4)
                                VStack(alignment: .leading, spacing: 4) {
                                    Text(title).font(Theme.ui(13, .medium)).foregroundStyle(Theme.ink)
                                    Text(detail).font(Theme.ui(12)).foregroundStyle(Theme.muted)
                                }
                                Spacer(minLength: 0)
                            }
                            .card(radius: 16, padding: 13)
                        }

                        PrimaryButton(title: miniRunning ? "Running Marvis Mini…"
                                                         : "Refresh Marvis Minis") {
                            miniRunning = true
                            Task {
                                await app.fetchLive()
                                miniRunning = false
                            }
                        }
                        .padding(.top, 8)
                    }
                    .padding(.horizontal, 20).padding(.top, 20)
                }
                .padding(.bottom, 32)
            }
        }
    }

    private func summary(_ d: Device) -> some View {
        VStack(alignment: .leading, spacing: 16) {
            HStack(alignment: .top, spacing: 12) {
                Text("\(d.model) · \(d.mac)")
                    .font(Theme.mono(11)).foregroundStyle(Theme.muted2).lineSpacing(4)
                Spacer(minLength: 8)
                Text(d.isDown ? "DISCONNECTED" : "CONNECTED")
                    .font(Theme.mono(10, .semibold)).tracking(0.6)
                    .foregroundStyle(d.isDown ? Color(hex: 0x9A3229) : Color(hex: 0x2A6B4C))
                    .padding(.horizontal, 10).padding(.vertical, 6)
                    .background(d.isDown ? Color(hex: 0xFBEAE7) : Color(hex: 0xE8F4ED), in: Capsule())
            }
            HStack(spacing: 10) {
                ForEach(stats(d), id: \.0) { value, label in
                    VStack(alignment: .leading, spacing: 3) {
                        Text(value).font(Theme.mono(18, .semibold)).tracking(-0.36)
                            .foregroundStyle(Theme.ink)
                        Text(label.uppercased()).font(Theme.mono(9.5)).tracking(0.76)
                            .foregroundStyle(Theme.muted2)
                    }
                    .frame(maxWidth: .infinity, alignment: .leading)
                }
            }
        }
        .padding(.horizontal, 20).padding(.top, 16).padding(.bottom, 20)
        .background(Theme.surface)
        .overlay(alignment: .bottom) { Divider().overlay(Theme.hairline) }
    }

    private func stats(_ d: Device) -> [(String, String)] {
        switch d.kind {
        case .ap: [("\(d.clients)", "Clients"), (d.isDown ? "down" : "up", "Status")]
        case .switchDevice: [("\(d.portsUp)/\(d.portsTotal)", "Ports"), (d.isDown ? "down" : "up", "Status")]
        case .gateway: [("\(Int(d.health))%", "Health"), (d.isDown ? "down" : "up", "Status")]
        }
    }

    private func portsLabel(_ d: Device) -> String {
        switch d.kind {
        case .ap: "Radios"
        case .switchDevice: "Ports"
        case .gateway: "WAN links"
        }
    }

    private struct Row { let key: String; let mid: String; let right: String; let value: String; let color: Color }

    private func rows(_ d: Device) -> [Row] {
        if app.isLive { return [] }
        switch d.kind {
        case .ap:
            return [
                Row(key: "2.4G", mid: "ch 6 · 11 dBm · 20 MHz", right: "\(Int(Double(d.clients) * 0.2)) cl", value: "34%", color: Theme.warn),
                Row(key: "5G", mid: "ch 44 · 17 dBm · 80 MHz", right: "\(Int(Double(d.clients) * 0.65)) cl", value: "71%", color: Theme.bad),
                Row(key: "6G", mid: "ch 69 · 15 dBm · 160 MHz", right: "\(Int(Double(d.clients) * 0.15)) cl", value: "9%", color: Theme.good)
            ]
        case .switchDevice:
            return [
                Row(key: "ge-0/0/1–12", mid: "access · VLAN 240", right: "12 up", value: "OK", color: Theme.good),
                Row(key: "ge-0/0/13–46", mid: "access · VLAN 100", right: "\(max(0, d.portsUp - 12)) up", value: "OK", color: Theme.good),
                Row(key: "xe-0/2/0", mid: "uplink · 10 Gbps", right: "1 up", value: "62%", color: Theme.warn)
            ]
        case .gateway:
            return [
                Row(key: "ISP-A", mid: "fibre · 1 Gbps", right: "up", value: "99%", color: Theme.good),
                Row(key: "ISP-B", mid: "broadband · 500 Mbps", right: "up", value: "78%", color: Theme.bad),
                Row(key: "LTE", mid: "backup · idle", right: "std", value: "—", color: Theme.muted2)
            ]
        }
    }

    private func rowView(_ r: Row) -> some View {
        HStack(spacing: 12) {
            Text(r.key).font(Theme.mono(12, .semibold)).foregroundStyle(Theme.ink)
                .frame(width: 52, alignment: .leading)
            Text(r.mid).font(Theme.mono(11)).foregroundStyle(Theme.muted)
            Spacer(minLength: 4)
            Text(r.right).font(Theme.mono(11)).foregroundStyle(Theme.muted2)
                .frame(width: 46, alignment: .trailing)
            Text(r.value).font(Theme.mono(11, .semibold)).foregroundStyle(r.color)
                .frame(width: 44, alignment: .trailing)
        }
        .card(radius: 14, padding: 13)
    }

    private func uplink(_ d: Device) -> [(String, String, Color)] {
        if app.isLive { return [] }
        if d.kind == .ap {
            let sw = app.devices.first { $0.kind == .switchDevice }?.name ?? "—"
            return [("Switch", sw, Theme.ink),
                    ("Port", "ge-0/0/12", Theme.ink),
                    ("Negotiated", "2.5 Gbps full", Theme.ink),
                    ("PoE", "802.3at · 11.4 / 30 W", Theme.ink),
                    ("Errors (24 h)", d.health < 80 ? "1 204 CRC" : "0",
                     d.health < 80 ? Theme.bad : Theme.ink)]
        }
        return [("CPU", "38%", Theme.ink), ("Memory", "54%", Theme.ink),
                ("Temperature", "41 °C", Theme.ink), ("Config sync", "in sync", Theme.good),
                ("Firmware", d.kind == .switchDevice ? "23.4R2-S3" : "23.2R1", Theme.ink)]
    }

    private func insights(_ d: Device) -> [(String, String, Color)] {
        let hits = app.visibleActions.filter {
            $0.cause.localizedCaseInsensitiveContains(d.name)
            || $0.cause.localizedCaseInsensitiveContains(d.mac)
            || $0.title.localizedCaseInsensitiveContains(d.name)
        }
        if !hits.isEmpty {
            return hits.map { ($0.title, $0.detail, color($0.severity)) }
        }
        if app.isLive {
            return [("No Marvis alarms for this device",
                     "Nothing in the current alarm search mentions this name or MAC.", Theme.good)]
        }
        guard d.health < 80 else {
            return [("No anomalies in the last 24 hours",
                     "Marvis has nothing flagged for this device.", Theme.good)]
        }
        switch d.kind {
        case .ap: return [
            ("Co-channel interference with a neighbour",
             "Two radios share a channel at high power.", Theme.warn)]
        case .switchDevice: return [
            ("PoE budget at 91% of capacity",
             "One more class-4 AP would drop the lowest-priority port.", Theme.warn)]
        case .gateway: return [
            ("ISP-B jitter above threshold",
             "Sustained 48 ms on the broadband path since 06:40.", Theme.bad)]
        }
    }

    private func color(_ s: MarvisAction.Severity) -> Color {
        switch s {
        case .critical: Theme.bad
        case .major: Theme.warn
        case .warning: Theme.accent
        }
    }
}
