import SwiftUI

struct MarvisView: View {
    @Environment(AppState.self) private var app

    var body: some View {
        VStack(spacing: 0) {
            AppHeader(title: "Marvis", subtitle: app.site.name)

            ScrollView {
                VStack(alignment: .leading, spacing: 22) {
                    VStack(spacing: 10) {
                        ForEach(app.visibleActions) { a in actionCard(a) }
                        if app.visibleActions.isEmpty {
                            DashedNote(text: "Nothing open at this site. Marvis will push here when an anomaly crosses threshold.")
                        }
                    }

                    VStack(alignment: .leading, spacing: 12) {
                        SectionHeader(text: "Marvis Minis", trailing: AnyView(
                            Button { runMinis() } label: {
                                Text(app.minisRunning ? "running…" : "run all ›")
                                    .font(Theme.mono(11)).foregroundStyle(Theme.accent)
                            }.buttonStyle(.plain)))

                        ForEach(app.visibleMinis) { m in
                            HStack(spacing: 11) {
                                Text(app.minisRunning ? "···" : m.result.rawValue)
                                    .font(Theme.mono(11, .semibold))
                                    .foregroundStyle(app.minisRunning ? Theme.muted2 : result(m.result))
                                    .frame(width: 50, alignment: .leading)
                                Text(m.name).font(Theme.ui(12.5)).foregroundStyle(Theme.ink2)
                                Spacer(minLength: 8)
                                Text(app.minisRunning ? "running" : m.age)
                                    .font(Theme.mono(10)).foregroundStyle(Theme.muted2)
                            }
                            .card(radius: 14, padding: 12)
                        }
                    }
                }
                .padding(.horizontal, 20).padding(.top, 16).padding(.bottom, 32)
            }
        }
        .background(Theme.bg)
        .task { await app.fetchLive() }
    }

    private func actionCard(_ a: MarvisAction) -> some View {
        let open = app.openAction == a.title
        return Button { app.openAction = open ? nil : a.title } label: {
            HStack(spacing: 0) {
                Rectangle().fill(color(a.severity)).frame(width: 3)
                VStack(alignment: .leading, spacing: 8) {
                    HStack {
                        Text(a.severity.rawValue.uppercased())
                            .font(Theme.mono(9.5, .semibold)).tracking(0.95)
                            .foregroundStyle(color(a.severity))
                        Spacer()
                        Text("\(a.impacted) \(a.impactedUnit)")
                            .font(Theme.mono(10)).foregroundStyle(Theme.muted2)
                    }
                    Text(a.title).font(Theme.ui(15, .medium)).foregroundStyle(Theme.ink)
                        .multilineTextAlignment(.leading)
                    Text(a.detail).font(Theme.ui(12.5)).foregroundStyle(Theme.muted)
                        .multilineTextAlignment(.leading)

                    if open {
                        Divider().overlay(Color(hex: 0xEFEAE1)).padding(.top, 4)
                        Text("ROOT CAUSE").font(Theme.mono(10)).tracking(1.2)
                            .foregroundStyle(Theme.muted2)
                        Text(a.cause).font(Theme.ui(12.5)).foregroundStyle(Theme.ink3)
                            .multilineTextAlignment(.leading).lineSpacing(3)
                        HStack(spacing: 8) {
                            PrimaryButton(title: a.cta) { app.openAction = nil }
                            Button { app.dismissed.insert(a.title); app.openAction = nil } label: {
                                Text("Dismiss")
                                    .font(Theme.ui(13, .medium)).foregroundStyle(Theme.ink3)
                                    .padding(.horizontal, 16).padding(.vertical, 12)
                                    .background(Color(hex: 0xEDE9E1),
                                                in: RoundedRectangle(cornerRadius: 11, style: .continuous))
                            }
                            .buttonStyle(.plain)
                        }
                        .padding(.top, 4)
                    }
                }
                .padding(.horizontal, 15).padding(.vertical, 14)
            }
            .background(Theme.surface)
            .clipShape(RoundedRectangle(cornerRadius: 16, style: .continuous))
            .overlay(RoundedRectangle(cornerRadius: 16, style: .continuous)
                .stroke(Theme.hairline, lineWidth: 1))
        }
        .buttonStyle(.plain)
    }

    private func runMinis() {
        Task {
            app.minisRunning = true
            await app.fetchLive()
            app.minisRunning = false
        }
    }

    private func color(_ s: MarvisAction.Severity) -> Color {
        switch s {
        case .critical: Theme.bad
        case .major: Theme.warn
        case .warning: Theme.accent
        }
    }
    private func result(_ r: Mini.Result) -> Color {
        switch r {
        case .pass: Theme.good
        case .warn: Theme.warn
        case .fail: Theme.bad
        }
    }
}
