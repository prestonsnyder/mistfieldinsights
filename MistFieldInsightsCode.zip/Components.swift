import SwiftUI

/// The ring gauge used on the dashboard.
struct SLEGauge: View {
    let score: Double
    var size: CGFloat = 62
    var lineWidth: CGFloat = 7

    var body: some View {
        ZStack {
            Circle().stroke(Color(hex: 0xF0ECE4), lineWidth: lineWidth)
            Circle()
                .trim(from: 0, to: score / 100)
                .stroke(Theme.status(score),
                        style: StrokeStyle(lineWidth: lineWidth, lineCap: .round))
                .rotationEffect(.degrees(-90))
        }
        .frame(width: size, height: size)
    }
}

struct DeltaLabel: View {
    let delta: Double
    var body: some View {
        Text(delta > 0 ? "▲ \(abs(delta), specifier: "%.1f")"
             : delta < 0 ? "▼ \(abs(delta), specifier: "%.1f")"
             : "· 0.0")
            .font(Theme.mono(10))
            .foregroundStyle(delta > 0 ? Theme.good : delta < 0 ? Theme.bad : Theme.muted2)
    }
}

struct ScoreBar: View {
    let score: Double
    var width: CGFloat? = nil
    var height: CGFloat = 6
    var body: some View {
        GeometryReader { geo in
            ZStack(alignment: .leading) {
                Capsule().fill(Color(hex: 0xF0ECE4))
                Capsule().fill(Theme.status(score))
                    .frame(width: geo.size.width * score / 100)
            }
        }
        .frame(width: width, height: height)
    }
}

struct StatusPill: View {
    let isLive: Bool
    let isLoading: Bool
    var body: some View {
        HStack(spacing: 6) {
            Circle()
                .fill(isLoading ? Theme.warn : isLive ? Theme.good : Theme.muted2)
                .frame(width: 7, height: 7)
            Text(isLoading ? "SYNC" : isLive ? "LIVE" : "OFFLINE")
                .font(Theme.mono(10, .semibold))
                .tracking(0.6)
                .foregroundStyle(Theme.ink3)
        }
        .padding(.horizontal, 11).padding(.vertical, 7)
        .background(Theme.chipBg, in: Capsule())
        .overlay(Capsule().stroke(Color(hex: 0xE4DFD5), lineWidth: 1))
    }
}

struct DashedNote: View {
    let text: String
    var body: some View {
        Text(text)
            .font(Theme.ui(12.5))
            .foregroundStyle(Theme.muted2)
            .lineSpacing(4)
            .frame(maxWidth: .infinity, alignment: .leading)
            .padding(15)
            .background(Theme.surfaceAlt,
                        in: RoundedRectangle(cornerRadius: 16, style: .continuous))
            .overlay(
                RoundedRectangle(cornerRadius: 16, style: .continuous)
                    .strokeBorder(Theme.hairlineDashed,
                                  style: StrokeStyle(lineWidth: 1, dash: [4, 3]))
            )
    }
}

struct PrimaryButton: View {
    let title: String
    let action: () -> Void
    var body: some View {
        Button(action: action) {
            Text(title)
                .font(Theme.ui(14, .medium))
                .foregroundStyle(.white)
                .frame(maxWidth: .infinity)
                .padding(.vertical, 15)
                .background(Theme.accent,
                            in: RoundedRectangle(cornerRadius: 14, style: .continuous))
        }
        .buttonStyle(.plain)
    }
}

struct Segmented: View {
    let options: [String]
    @Binding var selection: String
    var body: some View {
        HStack(spacing: 6) {
            ForEach(options, id: \.self) { option in
                Button { selection = option } label: {
                    Text(option)
                        .font(Theme.mono(11, .semibold))
                        .tracking(0.66)
                        .foregroundStyle(selection == option ? .white : Theme.muted2)
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 8)
                        .background(selection == option ? Theme.ink : Theme.surface,
                                    in: RoundedRectangle(cornerRadius: 10, style: .continuous))
                }
                .buttonStyle(.plain)
            }
        }
    }
}
