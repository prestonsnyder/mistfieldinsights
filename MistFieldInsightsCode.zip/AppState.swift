import SwiftUI
import Observation
import LocalAuthentication

struct Org: Identifiable, Hashable {
    let id: String
    let name: String
}

@MainActor
@Observable
final class AppState {
    enum Tab: String { case site, marvis, devices, settings }
    var tab: Tab = .site
    var path = NavigationPath()
    var pickerOpen = false

    var currentSiteId: String = ""
    var siteQuery = ""
    var deviceQuery = ""
    var range = "24H"
    var selectedMetricKey = "time-to-connect"
    var openClassifier: String? = "DHCP"
    var openAction: String?
    var dismissed: Set<String> = []
    var minisRunning = false
    var miniRunning = false

    private(set) var token = ""
    var orgId = ""
    var apiSiteId = ""
    var isLive = false
    var isLoading = false
    var errorMessage: String?
    var liveEnabled = false

    var orgs: [Org] = []
    var orgName = ""
    var didLoadOrgs = false
    private var didRestore = false
    private var fetchGeneration = 0
    private let cloudHost = URL(string: "https://api.ac2.mist.com")!

    var hasToken: Bool { !token.isEmpty }

    var waitingOnLive: Bool {
        hasToken && liveEnabled && (isLoading || !isLive)
    }

    enum SetupStage { case needsToken, needsOrg, needsSite, ready }
    var setupStage: SetupStage {
        if token.isEmpty { return .needsToken }
        if orgId.isEmpty { return .needsOrg }
        if apiSiteId.isEmpty { return .needsSite }
        return .ready
    }

    var sites: [Site] = []
    var metrics: [SLEMetric] = []
    var actions: [MarvisAction] = []
    var minis: [Mini] = []
    var devices: [Device] = []

    private let api = MistAPI()

    init() {}

    func restore() async {
        guard !didRestore else { return }
        didRestore = true
        guard TokenStore.hasItem else { return }
        guard let saved = TokenStore.load() else { return }
        token = saved.token
        orgId = saved.orgId
        orgName = saved.orgName
        apiSiteId = saved.siteId
        liveEnabled = true
        if orgId.isEmpty || apiSiteId.isEmpty {
            await connect()
            return
        }
        isLoading = true
        currentSiteId = apiSiteId
        await api.configure(host: cloudHost, token: token)
        if let found = try? await api.orgs().map({ Org(id: $0.id, name: $0.name) }) {
            orgs = found
            didLoadOrgs = true
            if let mine = found.first(where: { $0.id == orgId }) { orgName = mine.name }
        }
        if let live = try? await api.sites(orgId: orgId), !live.isEmpty {
            sites = live
                .map {
                    Site(id: $0.id, name: $0.name, region: $0.country_code ?? "",
                         apCount: 0, switchCount: 0, gatewayCount: 0)
                }
                .sorted { $0.name.localizedCaseInsensitiveCompare($1.name) == .orderedAscending }
            if !sites.contains(where: { $0.id == apiSiteId }) { apiSiteId = sites[0].id }
            currentSiteId = apiSiteId
            persist()
        }
        await fetchLive()
    }

    var site: Site { sites.first { $0.id == currentSiteId } ?? sites.first ?? .empty }

    var hasWired: Bool { devices.contains { $0.kind == .switchDevice } }
    var hasWAN: Bool { devices.contains { $0.kind == .gateway } }

    var visibleMetrics: [SLEMetric] {
        metrics.filter { m in
            switch m.family {
            case .wireless: true
            case .wired: hasWired
            case .wan: hasWAN
            }
        }
    }

    var visibleActions: [MarvisAction] {
        actions.filter { a in
            guard !dismissed.contains(a.title) else { return false }
            switch a.requires {
            case .none: return true
            case .switchDevice: return hasWired
            case .gateway: return hasWAN
            case .ap: return true
            }
        }
    }

    var visibleMinis: [Mini] {
        minis.filter { m in
            switch m.requires {
            case .none: true
            case .switchDevice: hasWired
            case .gateway: hasWAN
            case .ap: true
            }
        }
    }

    var infraLabel: String {
        hasWired && hasWAN ? "Wired & WAN" : hasWired ? "Wired" : "WAN"
    }

    var clientTotal: Int { devices.filter { $0.kind == .ap }.reduce(0) { $0 + $1.clients } }

    var subtitle: String {
        var parts = ["\(devices.filter { $0.kind == .ap }.count) APs"]
        let sw = devices.filter { $0.kind == .switchDevice }.count
        let gw = devices.filter { $0.kind == .gateway }.count
        if sw > 0 { parts.append("\(sw) \(sw == 1 ? "switch" : "switches")") }
        if gw > 0 { parts.append("\(gw) \(gw == 1 ? "gateway" : "gateways")") }
        return parts.joined(separator: " · ")
    }

    var selectedMetric: SLEMetric? {
        visibleMetrics.first { $0.key == selectedMetricKey } ?? visibleMetrics.first
    }

    func connect(using raw: String = "") async {
        let trimmed = (raw.isEmpty ? token : raw).trimmingCharacters(in: .whitespacesAndNewlines)
        guard TokenStore.isValidToken(trimmed) else {
            errorMessage = "Paste a valid Organization API Token first."
            return
        }
        token = trimmed
        liveEnabled = true
        isLoading = true
        errorMessage = nil
        didLoadOrgs = false
        await api.configure(host: cloudHost, token: trimmed)
        do {
            let found = try await api.orgs().map { Org(id: $0.id, name: $0.name) }
            orgs = found
            didLoadOrgs = true
            isLoading = false
            if found.isEmpty {
                errorMessage = "This token has no organization access. Create the token under Organization › API Tokens."
                return
            }
            persist()
            if found.count == 1 {
                await selectOrg(found[0])
            } else if let saved = found.first(where: { $0.id == orgId }) {
                await selectOrg(saved)
            } else {
                orgId = ""
                orgName = ""
                persist()
            }
        } catch {
            isLoading = false
            orgs = []
            isLive = false
            errorMessage = error.localizedDescription
        }
    }

    func selectOrg(_ org: Org) async {
        guard TokenStore.isValidID(org.id) else {
            errorMessage = "Organization id is not valid."
            return
        }
        orgId = org.id
        orgName = org.name
        apiSiteId = ""
        sites = []
        isLoading = true
        errorMessage = nil
        persist()
        await api.configure(host: cloudHost, token: token)
        do {
            let live = try await api.sites(orgId: org.id)
            sites = live
                .map {
                    Site(id: $0.id, name: $0.name, region: $0.country_code ?? "",
                         apCount: 0, switchCount: 0, gatewayCount: 0)
                }
                .sorted { $0.name.localizedCaseInsensitiveCompare($1.name) == .orderedAscending }
            isLoading = false
            if sites.isEmpty {
                errorMessage = "No sites found in \(org.name)."
            } else if sites.count == 1 {
                await selectSite(sites[0])
            }
        } catch {
            isLoading = false
            sites = []
            errorMessage = error.localizedDescription
        }
    }

    func selectSite(_ s: Site) async {
        guard TokenStore.isValidID(s.id) else {
            errorMessage = "Site id is not valid."
            return
        }
        currentSiteId = s.id
        apiSiteId = s.id
        liveEnabled = true
        dismissed = []
        openAction = nil
        path = NavigationPath()
        persist()
        await fetchLive()
    }

    func resetConnection() {
        fetchGeneration += 1
        token = ""
        orgId = ""
        orgName = ""
        apiSiteId = ""
        orgs = []
        didLoadOrgs = false
        liveEnabled = false
        isLive = false
        isLoading = false
        sites = []
        currentSiteId = ""
        devices = []
        metrics = []
        actions = []
        minis = []
        TokenStore.delete()
        errorMessage = nil
    }

    func select(site: Site) {
        currentSiteId = site.id
        apiSiteId = site.id
        liveEnabled = true
        pickerOpen = false
        siteQuery = ""
        deviceQuery = ""
        dismissed = []
        openAction = nil
        path = NavigationPath()
        tab = .site
        persist()
        Task { await fetchLive() }
    }

    private func persist() {
        guard !token.isEmpty else { return }
        if !TokenStore.save(SavedConnection(
            token: token, orgId: orgId, orgName: orgName, siteId: apiSiteId
        )) {
            errorMessage = "Could not save the connection to Keychain."
        }
    }
    private static func miniResult(_ d: MistAPI.MiniDTO) -> Mini.Result {
        let raw = (d.status ?? "").lowercased()
        if d.success == false || ["fail", "failed", "error", "timeout", "down"].contains(raw) {
            return .fail
        }
        if ["warn", "warning", "degraded", "partial"].contains(raw) {
            return .warn
        }
        return .pass
    }

    private static func miniAge(_ timestamp: Double?) -> String {
        guard let ts = timestamp, ts > 0 else { return "—" }
        let seconds = Date().timeIntervalSince1970 - ts
        if seconds < 90 { return "just now" }
        if seconds < 3600 { return "\(Int(seconds / 60))m ago" }
        if seconds < 86400 { return "\(Int(seconds / 3600))h ago" }
        return "\(Int(seconds / 86400))d ago"
    }

    private func mistKeys(for key: String) -> [String] {
        switch key {
        case "successful-connect", "successful-connects":
            return ["failed-to-connect", "successful-connects"]
        case "switch-successful-connect", "switch-successful-connects":
            return ["failed-to-connect", "successful-connects"]
        case "switch-health":
            return ["switch-health", "health"]
        case "switch-throughput":
            return ["switch-throughput", "throughput"]
        case "ap-health":
            return ["ap-availability", "ap-health"]
        default:
            return [key]
        }
    }

    private static func kind(for type: String?) -> DeviceKind {
        switch type {
        case "switch": return .switchDevice
        case "gateway", "router": return .gateway
        default: return .ap
        }
    }

    func fetchLive() async {
        fetchGeneration += 1
        let gen = fetchGeneration
        guard liveEnabled, !token.isEmpty, !apiSiteId.isEmpty else {
            if !liveEnabled { isLive = false }
            else {
                errorMessage = token.isEmpty
                    ? "Paste an Organization API Token first."
                    : "Select a site to load."
                isLive = false
            }
            return
        }

        isLoading = true
        errorMessage = nil
        await api.configure(host: cloudHost, token: token)
        guard gen == fetchGeneration else { return }

        let duration = range == "1H" ? "1h" : range == "7D" ? "7d" : "1d"
        do {
            if !orgId.isEmpty {
                if let liveSites = try? await api.sites(orgId: orgId), !liveSites.isEmpty {
                    guard gen == fetchGeneration else { return }
                    sites = liveSites.map {
                        Site(
                            id: $0.id,
                            name: $0.name,
                            region: $0.country_code ?? "",
                            apCount: 0,
                            switchCount: 0,
                            gatewayCount: 0
                        )
                    }
                    .sorted { $0.name.localizedCaseInsensitiveCompare($1.name) == .orderedAscending }
                    if apiSiteId.isEmpty || !sites.contains(where: { $0.id == apiSiteId }) {
                        apiSiteId = sites[0].id
                    }
                    currentSiteId = apiSiteId
                }
            }

            let stats = try await api.devices(siteId: apiSiteId)
            guard gen == fetchGeneration else { return }
            devices = stats.enumerated().map { i, d in
                Device(id: d.mac ?? "d\(i)",
                       kind: Self.kind(for: d.type),
                       name: d.name ?? d.mac ?? "—",
                       model: d.model ?? "—",
                       mac: d.mac ?? "—",
                       location: "",
                       clients: d.num_clients ?? 0,
                       portsUp: 0, portsTotal: 0,
                       health: d.status == "connected" ? 95 : 0,
                       isDown: d.status != "connected")
            }

            if let i = sites.firstIndex(where: { $0.id == apiSiteId }) {
                sites[i].apCount = devices.filter { $0.kind == .ap }.count
                sites[i].switchCount = devices.filter { $0.kind == .switchDevice }.count
                sites[i].gatewayCount = devices.filter { $0.kind == .gateway }.count
            }

            isLive = true

            var built: [SLEMetric] = []
            for template in SLECatalog.metrics {
                guard gen == fetchGeneration else { return }
                if template.family == .wired && !hasWired { continue }
                if template.family == .wan && !hasWAN { continue }
                var result: MistAPI.SLEResult?
                for key in mistKeys(for: template.key) {
                    result = try? await api.sleSummary(siteId: apiSiteId, metric: key, duration: duration)
                    if result != nil { break }
                }
                guard let result else { continue }
                var m = template
                m.score = result.score
                m.delta = 0
                m.impacted = result.impacted
                m.classifiers = result.classifiers
                built.append(m)
            }
            guard gen == fetchGeneration else { return }
            metrics = built

            actions = []
            if let dtos = try? await api.marvisActions(orgId: orgId, siteId: apiSiteId) {
                guard gen == fetchGeneration else { return }
                let downSwitches = devices.contains { $0.kind == .switchDevice && $0.isDown }
                let downAPs = devices.contains { $0.kind == .ap && $0.isDown }
                let downGWs = devices.contains { $0.kind == .gateway && $0.isDown }

                actions = dtos.compactMap { a in
                    let type = (a.type ?? "").lowercased()
                    if type.contains("switch") && type.contains("offline") && !downSwitches { return nil }
                    if type.contains("ap") && type.contains("offline") && !downAPs { return nil }
                    if type.contains("gateway") && type.contains("offline") && !downGWs { return nil }

                    let hosts = (a.hostnames ?? []) + (a.aps ?? []) + (a.switches ?? []) + (a.gateways ?? [])
                    let sev: MarvisAction.Severity = {
                        switch (a.severity ?? "").lowercased() {
                        case "critical": return .critical
                        case "warn", "warning", "major": return .major
                        default: return .warning
                        }
                    }()
                    return MarvisAction(
                        severity: sev,
                        title: (a.type ?? "marvis_action").replacingOccurrences(of: "_", with: " "),
                        detail: a.group ?? "marvis",
                        impacted: a.count ?? max(hosts.count, 1),
                        impactedUnit: "impacted",
                        cause: hosts.isEmpty
                            ? "Mist still has this alarm open. No matching hostname was attached."
                            : hosts.joined(separator: ", "),
                        cta: "Open runbook",
                        requires: nil)
                }
            }

            minis = []
            if let dtos = try? await api.minis(siteId: apiSiteId) {
                guard gen == fetchGeneration else { return }
                var latest: [String: MistAPI.MiniDTO] = [:]
                for d in dtos {
                    let key = d.type ?? "test"
                    if latest[key] == nil { latest[key] = d }
                }
                minis = latest.values.map { d in
                    Mini(
                        name: (d.type ?? "test").replacingOccurrences(of: "_", with: " "),
                        result: Self.miniResult(d),
                        age: Self.miniAge(d.timestamp),
                        requires: .none
                    )
                }
                .sorted { $0.name.localizedCaseInsensitiveCompare($1.name) == .orderedAscending }
            }
        } catch {
            guard gen == fetchGeneration else { return }
            isLive = false
            errorMessage = error.localizedDescription
        }
        guard gen == fetchGeneration else { return }
        isLoading = false
    }
}
