import SwiftUI

struct SettingsView: View {
    @Environment(AppState.self) private var app
    @State private var tokenDraft = ""

    var body: some View {
        @Bindable var app = app
        VStack(spacing: 0) {
            AppHeader(title: "Connection",
                      subtitle: app.isLive ? "Live data from the Mist API" : "Not connected")

            ScrollView {
                VStack(alignment: .leading, spacing: 18) {
                    Text("Paste an Organization API Token. The app reads your org and site list from it — no IDs to type.")
                        .font(Theme.ui(13.5)).foregroundStyle(Theme.muted).lineSpacing(4)

                    tokenStep
                    orgStep
                    siteStep

                    if let error = app.errorMessage {
                        Text(error)
                            .font(Theme.ui(12.5)).foregroundStyle(Color(hex: 0x9A3229))
                            .lineSpacing(3)
                            .frame(maxWidth: .infinity, alignment: .leading)
                            .padding(14)
                            .background(Color(hex: 0xFBEAE7),
                                        in: RoundedRectangle(cornerRadius: 14, style: .continuous))
                            .overlay(RoundedRectangle(cornerRadius: 14, style: .continuous)
                                .stroke(Color(hex: 0xF0C9C2), lineWidth: 1))
                    }

                    if !app.orgId.isEmpty || app.hasToken {
                        Button {
                            app.resetConnection()
                            tokenDraft = ""
                        } label: {
                            Text("Reset")
                                .font(Theme.ui(14, .medium))
                                .foregroundStyle(Theme.ink3)
                                .frame(maxWidth: .infinity)
                                .padding(.vertical, 15)
                                .background(Color(hex: 0xEDE9E1),
                                            in: RoundedRectangle(cornerRadius: 14, style: .continuous))
                        }
                        .buttonStyle(.plain)
                    }
                }
                .padding(.horizontal, 20).padding(.top, 18).padding(.bottom, 32)
            }
        }
        .background(Theme.bg)
    }

    private var tokenStep: some View {
        VStack(alignment: .leading, spacing: 10) {
            stepLabel(1, "Organization API Token")
            if app.hasToken && tokenDraft.isEmpty {
                staticRow(title: "Saved in Keychain",
                          note: "Paste a new token only if you need to replace it")
            }
            SecureField("Organization › Settings › API Tokens", text: $tokenDraft)
                .font(Theme.mono(13))
                .textInputAutocapitalization(.never)
                .autocorrectionDisabled()
                .padding(.horizontal, 14).padding(.vertical, 13)
                .background(Theme.surface,
                            in: RoundedRectangle(cornerRadius: 12, style: .continuous))
                .overlay(RoundedRectangle(cornerRadius: 12, style: .continuous)
                    .stroke(Color(hex: 0xE4DFD5), lineWidth: 1))
            PrimaryButton(title: app.isLoading ? "Checking…" : (app.didLoadOrgs ? "Re-check token" : "Continue")) {
                Task {
                    await app.connect(using: tokenDraft)
                    if app.errorMessage == nil { tokenDraft = "" }
                }
            }
        }
    }

    @ViewBuilder private var orgStep: some View {
        VStack(alignment: .leading, spacing: 10) {
            stepLabel(2, "Organization")

            if !app.didLoadOrgs && app.orgId.isEmpty {
                pendingRow("Enter a token to load your organizations")
            } else if app.orgs.count <= 1 {
                let name = app.orgs.first?.name ?? (app.orgName.isEmpty ? "—" : app.orgName)
                staticRow(title: name,
                          note: app.orgs.count == 1 ? "Only organization on this token" : "From saved connection")
            } else {
                Menu {
                    ForEach(app.orgs) { org in
                        Button(org.name) { Task { await app.selectOrg(org) } }
                    }
                } label: {
                    pickerRow(app.orgs.first { $0.id == app.orgId }?.name ?? "Select an organization",
                              placeholder: app.orgId.isEmpty)
                }
                .buttonStyle(.plain)
                Text("\(app.orgs.count) organizations available")
                    .font(Theme.mono(10)).foregroundStyle(Theme.muted2)
            }
        }
    }

    @ViewBuilder private var siteStep: some View {
        VStack(alignment: .leading, spacing: 10) {
            stepLabel(3, "Site")

            if app.orgId.isEmpty {
                pendingRow("Pick an organization first")
            } else if app.sites.isEmpty {
                pendingRow(app.isLoading ? "Loading sites…" : "No sites returned for this org")
            } else if app.sites.count == 1 {
                staticRow(title: app.sites[0].name, note: "Only site in this organization")
            } else {
                Menu {
                    ForEach(app.sites) { s in
                        Button(s.name) { Task { await app.selectSite(s) } }
                    }
                } label: {
                    pickerRow(app.sites.first { $0.id == app.apiSiteId }?.name ?? "Select a site",
                              placeholder: app.apiSiteId.isEmpty)
                }
                .buttonStyle(.plain)
                Text("\(app.sites.count) sites in org")
                    .font(Theme.mono(10)).foregroundStyle(Theme.muted2)
            }
        }
    }

    private func stepLabel(_ n: Int, _ text: String) -> some View {
        HStack(spacing: 8) {
            Text("\(n)").font(Theme.mono(10, .semibold))
                .foregroundStyle(.white)
                .frame(width: 17, height: 17)
                .background(Theme.ink3, in: Circle())
            Text(text.uppercased()).font(Theme.mono(10)).tracking(1)
                .foregroundStyle(Theme.muted2)
        }
    }

    private func pickerRow(_ title: String, placeholder: Bool) -> some View {
        HStack(spacing: 10) {
            Text(title).font(Theme.ui(14.5, .medium))
                .foregroundStyle(placeholder ? Theme.muted2 : Theme.ink)
                .lineLimit(1)
            Spacer(minLength: 8)
            Image(systemName: "chevron.up.chevron.down")
                .font(.system(size: 11, weight: .semibold))
                .foregroundStyle(Theme.muted2)
        }
        .padding(.horizontal, 14).padding(.vertical, 14)
        .background(Theme.surface,
                    in: RoundedRectangle(cornerRadius: 12, style: .continuous))
        .overlay(RoundedRectangle(cornerRadius: 12, style: .continuous)
            .stroke(Color(hex: 0xE4DFD5), lineWidth: 1))
    }

    private func staticRow(title: String, note: String) -> some View {
        VStack(alignment: .leading, spacing: 3) {
            Text(title).font(Theme.ui(14.5, .medium)).foregroundStyle(Theme.ink).lineLimit(1)
            Text(note).font(Theme.ui(11.5)).foregroundStyle(Theme.muted2)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(.horizontal, 14).padding(.vertical, 12)
        .background(Theme.surfaceAlt,
                    in: RoundedRectangle(cornerRadius: 12, style: .continuous))
        .overlay(RoundedRectangle(cornerRadius: 12, style: .continuous)
            .stroke(Color(hex: 0xE4DFD5), lineWidth: 1))
    }

    private func pendingRow(_ text: String) -> some View {
        Text(text)
            .font(Theme.ui(12.5)).foregroundStyle(Theme.muted2)
            .frame(maxWidth: .infinity, alignment: .leading)
            .padding(.horizontal, 14).padding(.vertical, 14)
            .background(Theme.surfaceAlt,
                        in: RoundedRectangle(cornerRadius: 12, style: .continuous))
            .overlay(RoundedRectangle(cornerRadius: 12, style: .continuous)
                .stroke(Color(hex: 0xE4DFD5), lineWidth: 1).opacity(0.6))
    }
}
