import SwiftUI

struct DashboardView: View {
    @Environment(AppState.self) private var app

    private var waiting: Bool { app.waitingOnLive }

    var body: some View {
        @Bindable var app = app
        VStack(spacing: 0) {
            AppHeader(title: app.site.name, subtitle: app.subtitle,
                      showChevron: true) { app.pickerOpen = true }

            ScrollView {
                VStack(alignment: .leading, spacing: 22) {
                    Segmented(options: ["1H", "24H", "7D"], selection: $app.range)

                    wireless
                    if waiting || app.hasWired || app.hasWAN { infra } else { wirelessOnlyNote }
                    marvis
                }
                .padding(.horizontal, 20)
                .padding(.top, 16)
                .padding(.bottom, 32)
            }
        }
        .background(Theme.bg)
        .task(id: app.range) { await app.fetchLive() }
    }

    private var wirelessCards: [SLEMetric] {
        if waiting {
            return SLECatalog.metrics.filter { $0.family == .wireless }
        }
        return app.visibleMetrics.filter { $0.family == .wireless }
    }

    private var infraCards: [SLEMetric] {
        if waiting {
            return SLECatalog.metrics.filter { $0.family != .wireless }
        }
        return app.visibleMetrics.filter { $0.family != .wireless }
    }

    private var wireless: some View {
        VStack(alignment: .leading, spacing: 12) {
            SectionHeader(text: "Wireless", trailing: AnyView(
                Text(waiting ? "loading" : "\(app.clientTotal) clients")
                    .font(Theme.mono(11)).foregroundStyle(Theme.muted2)))

            LazyVGrid(columns: [GridItem(.flexible(), spacing: 10),
                                GridItem(.flexible(), spacing: 10)], spacing: 10) {
                ForEach(wirelessCards) { m in
                    Button {
                        guard !waiting else { return }
                        app.selectedMetricKey = m.key
                        app.openClassifier = nil
                        app.path.append(Route.sle)
                    } label: {
                        VStack(alignment: .leading, spacing: 10) {
                            HStack {
                                if waiting {
                                    Circle()
                                        .stroke(Color(hex: 0xF0ECE4), lineWidth: 7)
                                        .frame(width: 62, height: 62)
                                } else {
                                    SLEGauge(score: m.score)
                                }
                                Spacer()
                                VStack(alignment: .trailing, spacing: 2) {
                                    Text(waiting ? "—" : "\(Int(m.score.rounded()))%")
                                        .font(Theme.mono(21, .semibold))
                                        .tracking(-0.63)
                                        .foregroundStyle(Theme.ink)
                                    Text(waiting ? "loading" : "")
                                        .font(Theme.mono(10))
                                        .foregroundStyle(Theme.muted2)
                                    if !waiting { DeltaLabel(delta: m.delta) }
                                }
                            }
                            VStack(alignment: .leading, spacing: 3) {
                                Text(m.name)
                                    .font(Theme.ui(13, .medium))
                                    .foregroundStyle(Theme.ink2)
                                    .multilineTextAlignment(.leading)
                                Text(waiting ? "syncing" : "\(m.impacted) impacted")
                                    .font(Theme.mono(10)).foregroundStyle(Theme.muted2)
                            }
                            .frame(maxWidth: .infinity, alignment: .leading)
                        }
                        .card(radius: 18, padding: 14)
                    }
                    .buttonStyle(.plain)
                    .disabled(waiting)
                }
            }
        }
    }

    private var infra: some View {
        VStack(alignment: .leading, spacing: 12) {
            SectionHeader(text: waiting ? "Wired" : app.infraLabel)
            ForEach(infraCards) { m in
                Button {
                    guard !waiting else { return }
                    app.selectedMetricKey = m.key
                    app.openClassifier = nil
                    app.path.append(Route.sle)
                } label: {
                    HStack(spacing: 12) {
                        RoundedRectangle(cornerRadius: 4)
                            .fill(waiting ? Color(hex: 0xE4DFD5) : Theme.status(m.score))
                            .frame(width: 4, height: 30)
                        VStack(alignment: .leading, spacing: 2) {
                            Text(m.name).font(Theme.ui(13, .medium)).foregroundStyle(Theme.ink2)
                            Text(waiting ? "syncing" : m.scope)
                                .font(Theme.mono(10)).foregroundStyle(Theme.muted2)
                        }
                        Spacer(minLength: 8)
                        if waiting {
                            Text("loading")
                                .font(Theme.mono(11))
                                .foregroundStyle(Theme.muted2)
                        } else {
                            ScoreBar(score: m.score, width: 68)
                            Text("\(Int(m.score.rounded()))%")
                                .font(Theme.mono(14, .semibold))
                                .foregroundStyle(Theme.ink)
                                .frame(width: 50, alignment: .trailing)
                        }
                    }
                    .card(radius: 14, padding: 12)
                }
                .buttonStyle(.plain)
                .disabled(waiting)
            }
        }
    }

    private var wirelessOnlyNote: some View {
        DashedNote(text: "Wireless only at this site. No switches or gateways are assigned, so wired and WAN service levels are hidden.")
    }

    private var marvis: some View {
        VStack(alignment: .leading, spacing: 12) {
            SectionHeader(text: "Marvis", trailing: AnyView(
                Button { app.tab = .marvis } label: {
                    Text(waiting ? "loading ›" : "\(app.visibleActions.count) open ›")
                        .font(Theme.mono(11)).foregroundStyle(Theme.accent)
                }.buttonStyle(.plain)
                .disabled(waiting)))

            if waiting {
                Text("loading")
                    .font(Theme.mono(11))
                    .foregroundStyle(Theme.muted2)
                    .card(radius: 16, padding: 13)
            } else {
                ForEach(app.visibleActions.prefix(2)) { a in
                    Button { app.tab = .marvis } label: {
                        HStack(alignment: .top, spacing: 11) {
                            Circle().fill(color(a.severity)).frame(width: 8, height: 8).padding(.top, 4)
                            VStack(alignment: .leading, spacing: 4) {
                                Text(a.title)
                                    .font(Theme.ui(13.5, .medium))
                                    .foregroundStyle(Theme.ink)
                                    .multilineTextAlignment(.leading)
                                Text("\(a.impacted) \(a.impactedUnit)")
                                    .font(Theme.mono(10)).foregroundStyle(Theme.muted2)
                            }
                            Spacer(minLength: 0)
                        }
                        .card(radius: 16, padding: 13)
                    }
                    .buttonStyle(.plain)
                }
            }
        }
    }

    private func color(_ s: MarvisAction.Severity) -> Color {
        switch s {
        case .critical: Theme.bad
        case .major: Theme.warn
        case .warning: Theme.accent
        }
    }
}
