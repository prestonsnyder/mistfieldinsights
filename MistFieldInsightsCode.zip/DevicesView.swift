import SwiftUI

struct DevicesView: View {
    @Environment(AppState.self) private var app

    var body: some View {
        @Bindable var app = app
        VStack(spacing: 0) {
            AppHeader(title: "Devices",
                      subtitle: "\(app.devices.count) at \(app.site.name)")

            ScrollView {
                VStack(alignment: .leading, spacing: 14) {
                    TextField("Search device or MAC", text: $app.deviceQuery)
                        .font(Theme.ui(15))
                        .textInputAutocapitalization(.never)
                        .autocorrectionDisabled()
                        .padding(.horizontal, 14).padding(.vertical, 12)
                        .background(Theme.surface,
                                    in: RoundedRectangle(cornerRadius: 12, style: .continuous))
                        .overlay(RoundedRectangle(cornerRadius: 12, style: .continuous)
                            .stroke(Color(hex: 0xE4DFD5), lineWidth: 1))

                    if filtered.isEmpty {
                        Text("No device matches that.")
                            .font(Theme.ui(13)).foregroundStyle(Theme.muted2)
                            .padding(.vertical, 24)
                    }

                    ForEach(filtered) { d in
                        Button { app.path.append(Route.device(d.id)) } label: { row(d) }
                            .buttonStyle(.plain)
                    }
                }
                .padding(.horizontal, 20).padding(.top, 16).padding(.bottom, 32)
            }
        }
        .background(Theme.bg)
        .task { await app.fetchLive() }
    }

    private var filtered: [Device] {
        let q = app.deviceQuery.trimmingCharacters(in: .whitespaces).lowercased()
        guard !q.isEmpty else { return app.devices }
        return app.devices.filter {
            "\($0.name) \($0.mac) \($0.model)".lowercased().contains(q)
        }
    }

    private func row(_ d: Device) -> some View {
        HStack(spacing: 12) {
            RoundedRectangle(cornerRadius: 4)
                .fill(d.isDown ? Theme.bad : Theme.status(d.health))
                .frame(width: 4, height: 32)
            VStack(alignment: .leading, spacing: 3) {
                Text(d.name).font(Theme.ui(13.5, .medium)).foregroundStyle(Theme.ink)
                Text("\(d.model) · \(d.mac)\(d.isDown ? " · DISCONNECTED" : "")")
                    .font(Theme.mono(10)).foregroundStyle(Theme.muted2).lineLimit(1)
            }
            Spacer(minLength: 8)
            VStack(alignment: .trailing, spacing: 2) {
                Text(primary(d)).font(Theme.mono(13, .semibold)).foregroundStyle(Theme.ink)
                Text(unit(d).uppercased()).font(Theme.mono(9)).tracking(0.54)
                    .foregroundStyle(Theme.muted2)
            }
        }
        .card(radius: 14, padding: 13)
    }

    private func primary(_ d: Device) -> String {
        switch d.kind {
        case .ap: "\(d.clients)"
        case .switchDevice: "\(d.portsUp)"
        case .gateway: "\(Int(d.health))%"
        }
    }
    private func unit(_ d: Device) -> String {
        switch d.kind {
        case .ap: "clients"
        case .switchDevice: "ports up"
        case .gateway: "health"
        }
    }
}
