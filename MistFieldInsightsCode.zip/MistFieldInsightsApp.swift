import SwiftUI

@main
struct MistFieldInsightsApp: App {
    @State private var state = AppState()
    var body: some Scene {
        WindowGroup { RootView().environment(state) }
    }
}

struct RootView: View {
    @Environment(AppState.self) private var app

    var body: some View {
        @Bindable var app = app
        VStack(spacing: 0) {
            NavigationStack(path: $app.path) {
                content
                    .background(Theme.bg)
                    .navigationBarTitleDisplayMode(.inline)
                    .toolbar(.hidden, for: .navigationBar)
                    .navigationDestination(for: Route.self) { route in
                        switch route {
                        case .sle: SLEDetailView()
                        case .device(let id): DeviceDetailView(deviceId: id)
                        }
                    }
            }
            TabBar()
        }
        .background(Theme.bg)
        .sheet(isPresented: $app.pickerOpen) { SitePickerView() }
        .task { await app.restore() }
    }

    @ViewBuilder private var content: some View {
        switch app.tab {
        case .site: DashboardView()
        case .marvis: MarvisView()
        case .devices: DevicesView()
        case .settings: SettingsView()
        }
    }
}

enum Route: Hashable {
    case sle
    case device(String)
}

struct AppHeader: View {
    let title: String
    let subtitle: String
    var showChevron = false
    var onTitleTap: (() -> Void)? = nil

    @Environment(AppState.self) private var app

    var body: some View {
        VStack(alignment: .leading, spacing: 0) {
            HStack(alignment: .center, spacing: 12) {
                Button { onTitleTap?() } label: {
                    VStack(alignment: .leading, spacing: 3) {
                        HStack(spacing: 7) {
                            Text(title)
                                .font(Theme.ui(20, .semibold))
                                .tracking(-0.24)
                                .foregroundStyle(Theme.ink)
                                .lineLimit(1)
                            if showChevron {
                                Text("⌄").font(.system(size: 13)).foregroundStyle(Theme.accent)
                            }
                        }
                        Text(subtitle)
                            .font(Theme.mono(10.5))
                            .foregroundStyle(Theme.muted2)
                            .lineLimit(1)
                    }
                }
                .buttonStyle(.plain)
                .disabled(onTitleTap == nil)

                Spacer(minLength: 8)

                Button { app.tab = .settings } label: {
                    StatusPill(isLive: app.isLive, isLoading: app.isLoading)
                }
                .buttonStyle(.plain)
            }
            .padding(.horizontal, 20)
            .padding(.top, 16)
            .padding(.bottom, 13)

            Divider().overlay(Theme.hairline)
        }
        .background(Theme.surface)
    }
}

struct TabBar: View {
    @Environment(AppState.self) private var app

    private let items: [(AppState.Tab, String, Bool)] = [
        (.site, "Site", false), (.marvis, "Marvis", true),
        (.devices, "Devices", false), (.settings, "Setup", true)
    ]

    var body: some View {
        VStack(spacing: 0) {
            Divider().overlay(Theme.hairline)
            HStack(spacing: 4) {
                ForEach(items, id: \.0) { tab, label, round in
                    Button {
                        app.tab = tab
                        app.path = NavigationPath()
                    } label: {
                        VStack(spacing: 5) {
                            RoundedRectangle(cornerRadius: round ? 9 : 4, style: .continuous)
                                .stroke(app.tab == tab ? Theme.accent : Theme.tabInactive, lineWidth: 2)
                                .background(
                                    RoundedRectangle(cornerRadius: round ? 9 : 4, style: .continuous)
                                        .fill(app.tab == tab ? Theme.accent : .clear))
                                .frame(width: 18, height: 18)
                            Text(label.uppercased())
                                .font(Theme.mono(9.5, .semibold))
                                .tracking(0.57)
                                .foregroundStyle(app.tab == tab ? Theme.accent : Theme.tabInactive)
                        }
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 6)
                    }
                    .buttonStyle(.plain)
                }
            }
            .padding(.horizontal, 12)
            .padding(.top, 10)
            .padding(.bottom, 10)
        }
        .background(.regularMaterial)
    }
}
